# VLKit: Vision and Learning Kit

### Installation
Install the latest version from source:
```
pip install git+https://github.com/vlkit/vlkit.git@master
```

or install from pypi:
```
pip install vlkit
```



