import numpy as np


class Scheduler(object):
    def __init__(self,
            epoch_iters: int,
            epochs: int,
            warmup_iters: int=0,
            warmup_epochs: int=0,
            warmup_init_lr: float=0,
            noice_std: float=.0,
            last_epoch: int=-1):

        assert not (warmup_epochs > 0 and warmup_iters > 0), \
               '\'warmup_epochs\' and \'warmup_iters\' cannot be both set!'

        self.max_iters = epoch_iters * epochs
        if warmup_epochs > 0:
            self.warmup_iters = warmup_epochs * epoch_iters
        else:
            self.warmup_iters = warmup_iters

        self.warmup_init_lr = warmup_init_lr
        # the a random value with std=noice_std will be added to the lr
        self.noice_std = noice_std

        self.last_epoch = last_epoch
        assert self.last_epoch >= -1

        self.iter = (self.last_epoch+1) * epoch_iters

    def step(self):
        self.iter += 1
        lr = self.get_lr(self.iter)
        if self.noice_std > 0:
            lr = max(lr + np.random.normal(scale=self.noice_std * lr), 0)
        return lr

    def get_lr():
        """compute and return the current learning rate
        
        """
        raise NotImplementedError
