import numpy as np
import math
from .base import Scheduler


class CosineScheduler(Scheduler):
    """Cosine learning rate scheduler

    Example:
    ::

        # multistep lr scheduler with warmup
        lr_scheduler = MultiStepScheduler(epoch_iters=1000, epochs=20, milestones=[4, 8], base_lr=0.1,
            gamma=[0.1, 0.1], warmup_iters=warmup_iters, warmup_init_lr=0.05)

        # cosine scheduler with warmup restarts and noice
        lr_scheduler = CosineScheduler(epoch_iters=1000, epochs=20, restarts=2,
                           restart_decay=0.8, max_lr=0.1, min_lr=0.01,
                           warmup_iters=warmup_iters, warmup_init_lr=0.05, noice_std=0.02)

    .. image:: _static/lr_scheduler.svg

    :param epoch_iters: number of interations in an epoch.
    :param epochs: maximal epochs.
    :param max_lr: maximal learning rate.
    :param min_lr: minimal learning rate, defaults to 0.
    :param warmup_iters: number of warmup epochs, defaults to 0.
    :param restarts: number of restars, defaults to 0.
    :param restart_decay: restart decay factor.
    :param last_epoch: last epoch.
    """
    def __init__(self,
            epoch_iters: int,
            epochs: int,
            warmup_iters: int=0,
            warmup_epochs: int=0,
            warmup_init_lr: float=0,
            max_lr: float=0.1,
            min_lr: float=0,
            restarts: int=0,
            restart_decay: float=0.1,
            last_epoch: int=-1, **kwargs):
        super(CosineScheduler, self).__init__(epoch_iters, epochs, warmup_iters, warmup_epochs,
                warmup_init_lr, **kwargs)

        assert restarts >= 0

        self.max_lr = max_lr
        self.min_lr = min_lr
        self.restarts = restarts
        self.restart_decay = restart_decay

        self.period = math.ceil((self.max_iters - self.warmup_iters) / (self.restarts + 1))
        assert self.last_epoch >= -1

    def get_lr(self, iter):
        if self.warmup_iters > 0 and iter <= self.warmup_iters:
            lr = self.warmup_init_lr + (iter / self.warmup_iters) * (self.max_lr - self.warmup_init_lr)
        else:
            round = (iter - self.warmup_iters - 1) // self.period
            step = (iter - self.warmup_iters - 1) % self.period
            base_lr = self.max_lr * (self.restart_decay ** round)
            assert base_lr > self.min_lr
            lr = (base_lr - self.min_lr) * (1 + math.cos((step / self.period) * math.pi)) / 2 + self.min_lr
        return lr
