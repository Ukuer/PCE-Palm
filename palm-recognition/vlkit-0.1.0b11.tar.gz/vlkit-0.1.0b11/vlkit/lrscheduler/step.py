import numpy as np
import math
from typing import Union, List
from .base import Scheduler

Num = Union[int, float]


class MultiStepScheduler(Scheduler):
    r"""multistep learning rate scheduler

        Args:
            epoch_iters (int): number of iterations in an epoch
            epochs (int): number of epochs
            milestones (int | tuple of ints): milestones to change learning rate
            gamma (float | tuple of float): learning rate decay factor (s)
            base_lr (float): base learning rate
            warmup_iters (int, optional): warmup_iters.
            warmup_init_lr (float, optional): warmup_init_lr.
    """
    def __init__(self,
            epoch_iters: int,
            epochs: int,
            milestones: List[int],
            gamma: float=None,
            gammas: List[float]=None,
            base_lr: float=0.1,
            warmup_iters: int=0,
            warmup_epochs: int=0,
            warmup_init_lr: float=0.0,
            **kwargs):
        

        super(MultiStepScheduler, self).__init__(epoch_iters, epochs,
                warmup_iters, warmup_epochs, warmup_init_lr, **kwargs)

        assert not (gamma is not None and gammas is not None), \
                '\'gamma\' and \'gammas\' cannot be both set.'

        if gamma is not None:
            gammas = [gamma,] * len(milestones)

        self.base_lr = base_lr
        self.milestones = [epoch_iters * i for i in milestones]
        self.gammas = gammas

        self.milestone_counter = 0

    def get_lr(self, iter):
        if self.warmup_iters > 0 and iter <= self.warmup_iters:
            lr = self.warmup_init_lr + (iter / self.warmup_iters) * (self.base_lr - self.warmup_init_lr)
        else:
            stage = np.digitize(iter, self.milestones)
            if stage == 0:
                lr = self.base_lr
            else:
                lr = self.base_lr * np.prod(self.gammas[:stage])
        return lr
