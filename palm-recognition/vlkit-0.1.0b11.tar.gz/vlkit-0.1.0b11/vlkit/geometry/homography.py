import numpy as np
from torchvision.transforms import RandomPerspective
from torchvision.transforms.functional import _get_perspective_coeffs, perspective, _get_perspective_coeffs


def random_perspective_matrix(width: int, height: int, distortion_scale: float):
    startpoints, endpoints = RandomPerspective.get_params(width, height, distortion_scale)
    coeffs = _get_perspective_coeffs(startpoints, endpoints)
    startpoints, endpoints = map(np.array, [startpoints, endpoints])
    M = np.array(coeffs + [1]).reshape(3,3)
    # inverse to calculate transform matrix from startpoints to endpoints
    M = np.linalg.inv(M)
    return M, (startpoints, endpoints), coeffs