import torch
import numpy as np
from ..utils import isarray


def minmax_normalize(x):
    assert isarray(x)
    if isinstance(x, np.ndarray):
        x -= x.min()



if __name__ == "__main__":
    minmax_normalize(torch.zeros(1, 4))
