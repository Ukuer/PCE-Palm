/*
 * Licensed under The MIT License
 * Written by KAI-ZHAO and Shanghua-Gao
 */
#ifndef _NMS_H
#define _NMS_H
void nms(float * in_array1, float * in_array2, float * out_array, int h, int w);
#endif
