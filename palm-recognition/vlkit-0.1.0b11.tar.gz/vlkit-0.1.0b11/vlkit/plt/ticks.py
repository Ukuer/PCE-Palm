def clear_ticks(axes):
    clear_xticks(axes)
    clear_yticks(axes)

def clear_xticks(axes):
    for ax in axes.flatten():
        ax.set_xticks([])

def clear_yticks(axes):
    for ax in axes.flatten():
        ax.set_yticks([])
