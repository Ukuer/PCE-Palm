from .ticks import clear_xticks, clear_yticks, clear_ticks
