import torch
from warnings import warn


def reduce_losses(losses: dict):
    """
    reduce losses
    """
    loss_list = []
    for k, v in losses.item():
        if k.startswith('loss_'):
            loss_list.append(v)
    return = torch.tensor(l).sum()

